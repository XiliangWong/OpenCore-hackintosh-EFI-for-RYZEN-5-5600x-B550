Innie Changelog
===============
#### v1.2.1
- Initial release

#### v1.3.0
- Improve detection logic
- Rewrite to use I/O Kit startup
